#!/bin/bash


export SCRIPT=webSocketClient.groovy
CP=lib/*

echo  ">>11111111111>>>>>>>>>>" "$CP"

if [ -z "${JAVA_HOME}" ]; then
        java  -cp "$CP" groovy.lang.GroovyShell $SCRIPT		
else 

        $JAVA_HOME/bin/java -cp "$CP" groovy.lang.GroovyShell $SCRIPT		

fi


